namespace human_resource_management.Areas.HumanResource.Data
{
    public class SalaryDetailViewModel
    {
        public int maChiTiet { get; set; }
        public int maNV { get; set; }
        public string hoTen { get; set; }
        public string chucVu { get; set; }
        public decimal luongThucNhan { get; set; }
        public decimal BaseSalary { get; set; }
        public int ngayCong { get; set; }
    }
}
